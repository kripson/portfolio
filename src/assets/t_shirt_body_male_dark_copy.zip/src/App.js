import Spline from '@splinetool/react-spline';

export default function App() {
  return (
    <Spline scene="https://prod.spline.design/8VgzyWL0oQahjjAT/scene.splinecode" />
  );
}
